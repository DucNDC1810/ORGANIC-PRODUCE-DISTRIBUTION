import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Callback for handling logout on token expiration
let onTokenExpiredCallback: (() => void) | null = null;

export const setTokenExpiredCallback = (callback: () => void) => {
  onTokenExpiredCallback = callback;
};

// Request interceptor
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      
      // Call the callback if set (for updating AuthContext)
      if (onTokenExpiredCallback) {
        onTokenExpiredCallback();
      } else {
        // Fallback to page redirect
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export default api;
